<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - Private Orders</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script> 
<link href="../css/main.css" rel="stylesheet" type="text/css" />

</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">



<?php
require('../includes/connection.php');
require_once("../source/include/membersite_config.php");
session_start();


if ($_SESSION['admin'])
    {
?>



<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php 
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else
    
$fgmembersite->RedirectToURL('login sessions/adminlogin.php');
$id = $_GET['id'];
$private = mysqli_query($connect->connection, "SELECT * FROM private_order WHERE `p_orderID`='$id'");
while($prrow = mysqli_fetch_assoc($private))
      {
		  $p_name = $prrow['ordername'];
		  $spec = $prrow['orderspec'];
		  $email = $prrow['email'];
		  $name = $prrow['name'];
		  $username = $prrow['username'];
		  $o_no = $prrow['p_ordernumber'];
		  $date = $prrow['orderdate'];
		  
      }
	  $fn = mysqli_query($connect->connection, "SELECT name FROM fgusers3 WHERE `username`='$username'");
	  $cfn = mysqli_fetch_assoc($fn);
	  $nfu = $cfn['name'];
	  $compose = "hello ".$nfu.". We are glad to inform you that your order id - ".$o_no." placed on ".$date." is available. proceed to.....";
?>
  <p>&nbsp;</p>
     <!-- sidebar -->
<div id="sidebar">
<ul id="side-menu">
<p>&nbsp;</p>
<li class="first"><a href="adminhome.php">My Menu</a></li>
<li class="first"><a href="myproducts.php">My Products</a></li>
<li class="first"><a href="myorders.php">My Orders</a></li>
<li class="first"><a href="private_order.php">My Private Orders</a></li>
<li class="first"><a href="adminpass.php">My Password</a></li>
</ul>			</div>
		<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>My Menu - private orders - send email</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
       <p>PRIVATE ORDER NO - <?php echo $o_no; ?></p>
       <?php
	   if (isset($_POST['send']))
	   {
		   $target = "../images/"; 
           $target = $target . basename( $_FILES['attach']['name']);

$newstat = "treated";
$sql = mysqli_query("UPDATE `private_order` SET `status`='$newstat' WHERE `p_orderID`='$id'");

		   require_once("../source/include/class.phpmailer.php");
		   $toemail = $_POST['to'];
		   $subject = $_POST['sub'];
		   $mbody = $_POST['body'];
		   $attach = $_FILES['attach']['name'];
		   $upload = move_uploaded_file(($_FILES['attach']['tmp_name']), $target);
			
$mail             = new PHPMailer(); // defaults to using php "mail()"

$body             = $mbody;
$body             = eregi_replace("[\]",'',$body);


$mail->SetFrom(CONF_GENERAL_EMAIL);


$address = $toemail;
$mail->AddAddress($address, $name);

$mail->Subject    = $subject;

$mail->MsgHTML($body);
if ($attach)
{
$mail->AddAttachment('../images/'.basename($attach));
}

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}

     }
	   else
	   {
	   ?>
       <form enctype="multipart/form-data" id='atc-form' action='<?php htmlspecialchars($_SERVER['PHP_SELF']) ?>' method='post' accept-charset='UTF-8'>
       
       <input type='hidden' name='submitted' id='submitted' value='1'/>
       
       <table cellpadding="10" cellspacing="5">
       <tr>
       <td>
       <label for='to' >To email: </label><br/>
       </td>
       <td>
       <input type='text' name='to' id='to' value="<?php echo $email; ?>"/><br/>
       
       </td>
       </tr>
       <tr>
       <td>
       <label for='sub' >Subject:</label><br/>
       </td>
       <td>
       <input type='text' value="Private Order Enquiry" name='sub' id='sub' size="40" /><br/>
      
       </td>
       </tr>
       <tr>
       <td>
       <label for='body' >Body:</label><br/>
       </td>
       <td>
       <textarea type='text' name='body' id='body' rows="10" cols="40"><?php echo $compose; ?></textarea><br/>
       
       </td>
       </tr>
       
        <tr>
       <td>
       <label for='attach' >attachment:</label><br/>
       </td>
       <td>
       <input type="file" name='attach' /><br/>
       
       </td>
       </tr>
        
       <tr>
       <td>
       <input type='submit' name="send"  value='SEND' />
       </td>
       <td></td>
       </tr>
       </table>
     </form>
    <?php } ?>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>