<?php
$child = array();
$childname = array();
$parent = array();
$parentname = array();
$urlp = array();
$urlc = array();
$c_result = mysqli_query($connect->connection, "SELECT * FROM categories WHERE !parentID=0 ORDER BY categoryID");
while($c_row = mysqli_fetch_assoc($c_result))
{ 
	$child[] = $c_row['parentID'];
	$childname[] = $c_row['cat_name'];
    $childcat[] = $c_row['categoryID'];
}
$p_result = mysqli_query($connect->connection, "SELECT * FROM categories WHERE parentID=0 ORDER BY categoryID");
while($p_row = mysqli_fetch_assoc($p_result))
{
	$parent[] = $p_row['categoryID'];
	$parentname[] = $p_row['cat_name'];
	$urlp[] = $p_row['urlname'];
}
$pageurl = $_SERVER['PHP_SELF'];

?>

<!DOCTYPE html> 
<html>
<head>
<!-- TemplateBeginEditable name="doctitle" -->
<title><?php echo $title; ?></title>
<!-- TemplateEndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link id="main-css" href="./css/main.css" rel="stylesheet" />
<!-- TemplateBeginEditable name="head" -->
<meta http-equiv="description" content="">
<meta http-equiv="keywords" content="">
<!-- TemplateEndEditable -->
</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

<li class="first"><a id="header-signin" href="source/login.php?redirectpage=<?=$pageurl?>">Sign In</a></li>
<li class="first"><a id="header-signin" href="accountmanager/index.php">My Account</a></li>
<li class="last"><a id="header-signin" href="source/register.php">Register</a></li>

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<a href="home.php"><img src="images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" /></a>
</div>
</div>
</div>
<!-- main menu -->
<div id="top-wrapper">
<div id="top" class="content">
<div id="top-search">
<form id="top-search-form" method="get" action="search.php" >
<input name="Search" type="submit" value="Search" id="top-search-submit" alt="Search" class="button" />
<input type="text" name="S_ProductName" id="top-search-query" value="" placeholder="Search..." />
</form>
</div>
<ul id="top-menu">
<li><a rel="" target=""><strong>Products</strong></a>
<ul>

<?php
for($e=0; $e< count($parentname);$e++){

?>
<li class="first"><a href="products.php?index=<?=$urlp[$e]?>&result=<?=$parent[$e]?>" rel="" target=""><strong><?php print $parentname[$e]; ?></strong></a>


<span class="catwrp">
<?php
	for($s=0; $s< count($child);$s++ ){
        if($child[$s]==$parent[$e]){ ?>
<a href="product.php?index=<?=$urlp[$e]?>&result=<?=$childcat[$s]?>" rel="" target=""><strong><?php echo $childname[$s]; ?></strong></a>

<?php }} ?>
</span>
</li>
<?php } ?>
</ul>
</li>
<li class="first"><a href="topselling.php" rel="" target=""><strong>Top Sellers</strong></a></li>
<li class="first"><a href="newarrivals.php" rel="" target=""><strong>New Arrivals</strong></a></li>
<li class="first"><a href="#" rel="" target=""><strong>Order Tracking</strong></a></li>
<li class="first"><a href="privateorder.php" rel="" target=""><strong>Private Order</strong></a></li>
</li>
</ul>
</div>
</div>
<div id="content-wrapper">
<div id="content" class="content">