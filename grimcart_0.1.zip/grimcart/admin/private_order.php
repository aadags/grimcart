<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - Private Orders</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script> 
<link href="../css/main.css" rel="stylesheet" type="text/css" />

</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">



<?php
require('../includes/connection.php');
require_once("../source/include/membersite_config.php");
session_start();

if ($_SESSION['admin'])
    {
?>



<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php 
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else
    
$fgmembersite->RedirectToURL('login sessions/adminlogin.php');
$private = mysqli_query($connect->connection, "SELECT * FROM private_order ORDER BY p_orderID DESC");
?>
	<p>&nbsp;</p>
     <!-- sidebar -->
<div id="sidebar">
<ul id="side-menu">
<p>&nbsp;</p>
<li class="first"><a href="adminhome.php">My Menu</a></li>
<li class="first"><a href="myproducts.php">My Products</a></li>
<li class="first"><a href="myorders.php">My Orders</a></li>
<li class="first"><a href="private_order.php">My Private Orders</a></li>
<li class="first"><a href="adminpass.php">My Password</a></li>
</ul>			</div>
		<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>My Menu - private orders</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
       <p>&nbsp;</p>
       <b style="color:#F00">**HINTS**</b><br/>
    <b style="color:#F00">-- click on each row to view full details or to finish up the order</b><br/>  
       <b style="color:#F00">-- "not treated" means you have not checked an order</b><br/>
        <b style="color:#F00"> -- "under processing" indicates that you have seen and checked the order...clicking on the order to compose and reply the customer order enquiry</b><br/>
        <p>&nbsp;</p>
       <div id="adminbox">
       <table border="0" style="background:#666; font-family:Verdana, Geneva, sans-serif; font-size:11px; color:#FFF;" align="center" bordercolor="#0099FF" cellpadding="2" cellspacing="1">
       <tr>
       <td>ID NO</td><td>PRODUCT NAME</td><td>ORDER NO</td><td>EMAIL</td><td>STATUS</td><td>DATE</td>
       </tr>
       <?PHP
       $x = 1;
       while($prrow = mysqli_fetch_assoc($private))
      {  
	  ?>
      <tr bgcolor="#FFFFFF" style="color:#000" class="pod product-list-item" title="click to view details" onclick="window.location='viewp_order.php?id=<?=$prrow['p_orderID']?>'">
       <td><?php echo $x; $x++ ?></td>
       <td><?php echo $prrow['ordername']; ?></td>
       <td><?php echo $prrow['p_ordernumber']; ?></td>
       <td><?php echo $prrow['email']; ?></td>
       <td><?php echo $prrow['status']; ?></td>
       <td><?php echo $prrow['orderdate']; ?></td>
       </tr>
   
       <?PHP } ?>
       </table>
      </div>

</div>
<p>&nbsp;</p>
      <p>&nbsp;</p>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>