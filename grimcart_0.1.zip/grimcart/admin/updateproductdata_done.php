<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - edit product</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script> 
<link href="../css/main.css" rel="stylesheet" type="text/css" />
</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">



<?php
require('../includes/connection.php');
require('../includes/class.library.php');
require_once("../source/include/membersite_config.php");
session_start();
$admin_upload = new form();

if ($_SESSION['admin'])
    {
?>

<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php 
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else
    
$fgmembersite->RedirectToURL('login sessions/adminlogin.php');


?>
	<p>&nbsp;</p>
     <!-- sidebar -->
<div id="sidebar">
<ul id="side-menu">
<p>&nbsp;</p>
<li class="first"><a href="adminhome.php">My Menu</a></li>
<li class="first"><a href="myproducts.php">My Products</a></li>
<li class="first"><a href="myorders.php">My Orders</a></li>
<li class="first"><a href="private_order.php">My Private Orders</a></li>
<li class="first"><a href="adminpass.php">My Password</a></li>
</ul>			</div>
		<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>My Menu - edit product</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
       <font>Note: file upload must not be more than 2mb.</font>
 <?php
 if(isset($_GET['id']))
 {
     $id = $_GET['id']; 
	 
	 $getpic = mysqli_query($connect->connection, "SELECT * FROM products WHERE `productID`='$id'");
	 while($picrow = mysqli_fetch_assoc($getpic))
	{
		$p1 = $picrow['picture1'];
		$p2 = $picrow['picture2'];
		$p3 = $picrow['picture3'];
		$p4 = $picrow['picture4'];
		$p5 = $picrow['picture5'];
	}
	 
	 if(isset($_POST['udata'])){
	 
	$prod_name = $admin_upload->test_input($_POST['productname']);
	$p_desc = $admin_upload->test_input($_POST['prod_desc']);
    $p_price = $admin_upload->test_input($_POST['price']);
	$l_price = $admin_upload->test_input($_POST['listprice']);
	$prod_sku = $admin_upload->test_input($_POST['prod_sku']);
	$c_id = $admin_upload->test_input($_POST['categoryid']);
	$prod_spec = $admin_upload->test_input($_POST['prod_spec']);
	$instock = $admin_upload->test_input($_POST['stock']);
    $shipping = $admin_upload->test_input($_POST['shipprice']);
	$thumbnail = $_FILES['thumbnail']['name'];
	
	$target = "../images/thumbnail/"; 

$target = $target . basename( $_FILES['thumbnail']['name']);
	
 if ( $thumbnail == false )
{
	 if ( $prod_name == false )
{
	echo "<p style='color:#F00'><strong>Name cannot be left blank!</strong></p>";
}
else if ( $p_desc == false )
{
	echo "<p style='color:#F00'><strong>Description cannot be left blank!</strong></p>";
}
else if ( $p_price == false )
{
	echo "<p style='color:#F00'><strong>Price cannot be left blank!</strong></p>";
}
else if ( $shipping == false )
{
	echo "<p style='color:#F00'><strong>Shipment Price cannot be left blank!</strong></p>";
}

else if ( $prod_sku == false )
{
	echo "<p style='color:#F00'><strong>Product Sku cannot be left blank!</strong></p>";
}
else{

	
	$sql = mysqli_query($connect->connection, "UPDATE `products` SET `prod_name`='$prod_name',`prod_specs`='$prod_spec',`in_stock`='$instock',`price`='$p_price',`prod_desc`='$p_desc',`prod_sku`='$prod_sku',`listprice`='$l_price',`shipment`='$shipping',`categoryID`='$c_id' WHERE `productID`='$id'");


	if ($sql)
	{
		 ?>
        <div id="adminbox">
       <center><a class="button" href="dopicupdate_skip.php">>> SKIP</a></center><br/><br/>
       <label style="font-size:18px"><h1>Product Gallery</h1></label>
       <form action="dopicupdate.php?sku=<?=$prod_sku?>" id="atc-form" method="post" enctype="multipart/form-data">
       <table cellpadding="5" cellspacing="5">
       <tr>
       <td>
       <label>Preview 1:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p1; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 2:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p2; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 3:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p3; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 4:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p4; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 5:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p5; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 1:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 2:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 3:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 4:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 5:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       
        <tr>
       <td>
       <input type='submit' class="button"  value='SAVE' />
       <input type="button" class="button"  value='SKIP' onclick="window.location='dopicupdate_skip.php'" />
       </td>
       <td></td>
       </tr>
       </table>
       </form>
       </div>
        
        <?php
	}
	else
	{
		echo'data not saved successfully to database ';
	
	}
}
}
else{
	
	
 if ( $prod_name == false )
{
	echo "<p style='color:#F00'><strong>Name cannot be left blank!</strong></p>";
}
else if ( $p_desc == false )
{
	echo "<p style='color:#F00'><strong>Description cannot be left blank!</strong></p>";
}
else if ( $p_price == false )
{
	echo "<p style='color:#F00'><strong>Price cannot be left blank!</strong></p>";
}
else if ( $shipping == false )
{
	echo "<p style='color:#F00'><strong>Shipment Price cannot be left blank!</strong></p>";
}
else if ( $prod_sku == false )
{
	echo "<p style='color:#F00'><strong>Product Sku cannot be left blank!</strong></p>";
}

else{
	$allowedExts = array("gif","jpeg","jpg","png");
	$temp = explode(".", $_FILES['thumbnail']['name']);
	$extension = end($temp);
	
	if ((($_FILES['thumbnail']['type'] == "image/gif") || ($_FILES['thumbnail']['type'] == "image/jpeg") || ($_FILES['thumbnail']['type'] == "image/jpg") || ($_FILES['thumbnail']['type'] == "image/pjpeg") || ($_FILES['thumbnail']['type'] == "image/x-png") || ($_FILES['thumbnail']['type'] == "image/png") && in_array($extension, $allowedExts)))																																																																														{
																																																																															 if ($_FILES['thumbnail']['error']> 0)																																																																													 {
	echo "error : ".$_FILES['thumbnail']['error']."<br>";
																																																																															 }
																																																																															 else
																																																																															 {
	
	if(move_uploaded_file(($_FILES['thumbnail']['tmp_name']), $target)) 
      { 
	   	
	$sql = mysqli_query($connect->connection, "UPDATE `products` SET `prod_name`='$prod_name',`prod_specs`='$prod_spec',`in_stock`='$instock',`price`='$p_price',`prod_desc`='$p_desc',`prod_sku`='$prod_sku',`listprice`='$l_price',`thumbnail`='$thumbnail' WHERE `productID`='$id'");


	if ($sql)
	{
		?>
        <br/><br/>
        <div id="adminbox">
		   <center><a class="button" href="dopicupdate_skip.php">>> SKIP</a></center><br/><br/>
       <label style="font-size:18px"><h1>Product Gallery</h1></label>
       <form action="dopicupdate.php?sku=<?=$prod_sku?>" id="atc-form" method="post" enctype="multipart/form-data">
       <table cellpadding="5" cellspacing="5">  
         <tr>
       <td>
       <label>Preview 1:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p1; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 2:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p2; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 3:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p3; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 4:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p4; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
         <tr>
       <td>
       <label>Preview 5:</label><br/>
       </td>
       <td>
       <img src="<?php echo "../images/products/".$p5; ?>" width="140" height="140" border="0" class="WADAResultThumb" title="" />
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 1:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 2:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 3:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 4:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       <tr>     
       <td>
       <label>New product picture 5:</label><br/>
       </td>
       <td>
       <input type='file' name='files[]' multiple/><br/>
       
       </td>
       </tr>
       
        <tr>
       <td>
       <input type='submit' class="button"  value='SAVE' />
       <input type="button" class="button"  value='SKIP' onclick="window.location='dopicupdate_skip.php'"/>
       </td>
       <td></td>
       </tr>
       </table>
       </form>
       </div>
        
        <?php
	}
	else
	{
		echo'Error uploading your data.';
	
	}
	 }
        else { 
             //Gives an error if its not 
             echo "Sorry, there was a problem uploading thumbnail ". basename( $_FILES['thumbnail']['name'])."due to error : ".$_FILES['thumbnail']['error']; 
             }	
																																																																															 }
																																																																																																																																																																																																																																												 }
																																																																																																																																																																																																																																												 else {	echo "invalid file";}																																																																													 																																																																															 }
	
}
 }
	
 }
 else
 $fgmembersite->RedirectToURL('updateproduct.php');
   ?>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>