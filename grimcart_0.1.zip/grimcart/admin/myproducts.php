<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - All Products</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script>
<link href="../css/main.css" rel="stylesheet" type="text/css" />

</head>
<body class="products_results">
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >

  <div id="content" class="content">



<?php
require('../includes/connection.php');
require('../includes/class.library.php');
require_once("../source/include/membersite_config.php");
session_start();

$adfunc = new functions();

if ($_SESSION['admin'])
    {
?>



<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else

$fgmembersite->RedirectToURL('login sessions/adminlogin.php');
$child = array();
$childname = array();
$parent = array();
$parentname = array();
$pid[] = array();
$prod = array();
$prod_id = array();
$c_result = mysqli_query($connect->connection, "SELECT * FROM categories WHERE !parentID=0 ORDER BY categoryID");
while($c_row = mysqli_fetch_assoc($c_result))
{
	$child[] = $c_row['parentID'];
	$childname[] = $c_row['cat_name'];
    $childcat[] = $c_row['categoryID'];
}
$p_result = mysqli_query($connect->connection, "SELECT * FROM categories WHERE parentID=0 ORDER BY categoryID");
while($p_row = mysqli_fetch_assoc($p_result))
{
	$parent[] = $p_row['categoryID'];
	$parentname[] = $p_row['cat_name'];
}
$prods = mysqli_query($connect->connection, "SELECT * FROM products");
while($prod_row = mysqli_fetch_assoc($prods))
{
	$prod_id[] = $prod_row['categoryID'];
	$prod[] = $prod_row['prod_name'];
	$pid[] = $prod_row['productID'];
}

$pno = mysqli_query($connect->connection, "SELECT COUNT(*) AS NumberOfPro FROM products");
$pnorow = mysqli_fetch_assoc($pno);
$p_no = $pnorow['NumberOfPro'];

$cno = mysqli_query($connect->connection, "SELECT COUNT(*) AS NumberOfcat FROM categories WHERE parentID=0");
$cnorow = mysqli_fetch_assoc($cno);
$c_no = $cnorow['NumberOfcat'];

$sno = mysqli_query($connect->connection, "SELECT COUNT(*) AS NumberOfsub FROM categories WHERE !parentID=0");
$snorow = mysqli_fetch_assoc($sno);
$s_no = $snorow['NumberOfsub'];

?>
	<p>&nbsp;</p>
     <!-- sidebar -->
<div id="sidebar">
<ul id="side-menu">
<p>&nbsp;</p>
<li class="first"><a href="adminhome.php">My Menu</a></li>
<li class="first"><a href="myproducts.php">My Products</a></li>
<li class="first"><a href="myorders.php">My Orders</a></li>
<li class="first"><a href="private_order.php">My Private Orders</a></li>
<li class="first"><a href="adminpass.php">My Password</a></li>
</ul>			</div>
		<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>My Menu - my products</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
       <p>&nbsp;</p>
     <div id="adminbox">

     <table>
     <td valign="top" bgcolor="#E2E2FF" width="25%">
     <small style="float: right"><b>you have <?php echo $p_no; ?> products,<br/><?php echo $s_no; ?> sub categories<br/> and <?php echo $c_no; ?> categories.</b></small>
     <?php for($e=0; $e< count($parentname);$e++){ ?>
    <table>
    <td>
    <tr>
     <?php print "<dd><b style='color:#009; text-decoration: underline'>".$parentname[$e]."</b></dd>"; ?>
    </tr>
     </td>
     </table>

     <?php
	 for($s=0; $s< count($child);$s++ ){
        if($child[$s]==$parent[$e]){ ?>
        <table>
        <td>
		  <tr>
	      <?php  echo "<dd style='text-decoration: underline; color:#FF0000'>".$childname[$s]."<dd>"; ?>
            </tr>
            </td>
            </table>
            <?php

	        for($n=0; $n< count($prod);$n++ ){
                if($prod_id[$n]==$childcat[$s]){ ?>
                <table>
                <td>
                <tr>
                <?php
				echo "<dd>".$prod[$n]."&nbsp;&nbsp;[".$adfunc->get_stock($pid[$n+1])."]</dd>"; ?>
                </tr>
                </td>
                </table>
                <?php
		   }}
		}}

	 }
	 ?>
              </td>
          </table>
</div>
        
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>