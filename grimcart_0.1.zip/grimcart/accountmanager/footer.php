<div id="footer-wrapper">
<div id="footer" class="content">
<ul><table width="760" height="100" align="center">
  <tr>
    <td align="center" width="253">Policy & Info</a></td>
    <td align="center" width="253">Customer Service</td>
    <td align="center" width="253">Best Buys</td>
    <td align="center" width="234">Help & Assitance</a></td>
  </tr>
  <tr>
    <td align="center"><a rel="" target="_blank" href="#">About Us</a></td>
    <td align="center"><a rel="" target="_blank" href="../privateorder.php">Private Order</a></td>
    <td align="center"><a rel="" target="_blank" href="#">Deals</a></td>
    <td align="center"><a rel="" target="_blank" href="#">Contact Us</a></td>
  </tr>
  <tr>
    <td align="center"><a rel="" target="_blank" href="../privacy.html">Privacy Statement</a></td>
    <td align="center"><a rel="" target="_blank" href="#">Shipping</a></td>
    <td align="center"><a rel="" target="_blank" href="#">Prices</a></td>
    <td align="center"><a rel="" target="_blank" href="#">Site Map</a></td>
  </tr>
  <tr>
    <td align="center"><a rel="" target="_blank" href="../FAQ.php">FAQ</a></td>
    <td></td>
    <td></td>
    <td align="center"><a rel="" target="_blank" href="#">Term of Use</a></td>
    </tr>
</table>
</ul>
<ul>
<p> � 2014 <a href="../home.php"><?php echo $sitename; ?></a>. All Rights Reserved. </p>
</ul>
</div>
</div>
<!-- TemplateBeginEditable name="end" --><!-- TemplateEndEditable -->
</body>
<!-- TemplateBeginEditable name="doctitle" -->
<title><?php echo $title; ?></title>
<!-- TemplateEndEditable -->
</html>