<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - Private Orders</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script> 
<link href="../css/main.css" rel="stylesheet" type="text/css" />
<link href="../source/style/fg_membersite.css" rel="stylesheet" type="text/css" />
</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">



<?php
require('../includes/connection.php');
require_once("../source/include/membersite_config.php");
session_start();

if ($_SESSION['admin'])
    {
?>



<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php 
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else
    
$fgmembersite->RedirectToURL('login sessions/adminlogin.php');
$id = $_GET['id'];
$private = mysqli_query($connect->connection, "SELECT * FROM private_order WHERE `p_orderID`='$id'");
while($prrow = mysqli_fetch_assoc($private))
      {
		  $p_name = $prrow['ordername'];
		  $spec = $prrow['orderspec'];
		  $email = $prrow['email'];
		  $name = $prrow['name'];
		  $username = $prrow['username'];
		  $o_no = $prrow['p_ordernumber'];
		  $stat = $prrow['status'];
		  $date = $prrow['orderdate'];
      }
?>
	<p>&nbsp;</p>
   
 
<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>My Menu - private orders</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
             <p>&nbsp;</p>
             <p>&nbsp;</p>
       <table style="background:#666; font-family:Verdana, Geneva, sans-serif; font-size:11px; color:#FFF;" width="909" border="0" align="center" cellpadding="2" cellspacing="1" bordercolor="#0099FF">
       <tr>
       <td>ID NO</td><td>PRODUCT NAME</td><td>ORDER NO</td><td>SPECIFICATIONS</td><td>EMAIL</td><td>NAME</td><td>USERNAME</td><td>DATE</td>
       </tr>
       <tr bgcolor="#FFFFFF" style="color:#000">
       <td><?php echo $id; ?></td>
       <td><?php echo $p_name; ?></td>
       <td><?php echo $o_no; ?></td>
       <td><div id="fb"><?php echo $spec; ?></div></td>
       <td><?php echo $email; ?></td>
       <td><?php echo $name; ?></td>
       <td><?php echo $username; ?></td>
       <td><?php echo $date; ?></td>
       </tr>
       <tr>
      
      
       </table>
       <p>&nbsp;</p>
       
       
       <?php
	   if ( $stat == "treated" )
	   echo "<b>order has been treated</b>";
	   
	   else if( $stat == "not treated" )
	   {?>
       <p>Clicking <b>DONE</b> means you have seen this order and is under processing!</p>
       <table>
       <tr>
       <td>
        <a href="private_order.php" class="button">cancel</a> 
        </td>
        <td>
        <a href="done.php?id=<?=$id?>" class="button">done</a>
        </td>
        </tr>
        </table> 
		<?php }else{ ?>
       <p>Click on <b>SENDMAIL</b> to compose and reply this order enquiry via email</p>
        <table>
       <tr>
       <td>
        <a href="private_order.php" class="button">cancel</a> 
        </td>
        <td>
         <a href="sendmail.php?id=<?=$id?>" class="button">sendmail</a>
        </td>
        </tr>
        </table> 
         <?php } ?>
      
         
       <p>&nbsp;</p>
       <p>&nbsp;</p>
      
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>