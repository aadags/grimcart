<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin - My Orders</title>
<script src="../Templates/includes/ice/ice.js" type="text/javascript"></script> 
<link href="../css/main.css" rel="stylesheet" type="text/css" />

</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">



<?php
require('../includes/connection.php');
require_once("../source/include/membersite_config.php");
session_start();

if ($_SESSION['admin'])
    {
?>



<!-- content -->
<div align="center" id="content">
<h1>ADMIN PAGE</h1>
<?php 
echo "<h2>".$_SESSION['admin']."!</h2><a href='login sessions/adminlogout.php'>Logout</a>";}
else
    
$fgmembersite->RedirectToURL('login sessions/adminlogin.php');

if(isset($_GET['id'])){
$oid = $_GET['id'];

?>
	<p>&nbsp;</p>
     <!-- sidebar -->
<div id="sidebar">
<ul id="side-menu">
<p>&nbsp;</p>
<li class="first"><a href="adminhome.php">My Menu</a></li>
<li class="first"><a href="myproducts.php">My Products</a></li>
<li class="first"><a href="myorders.php">My Orders</a></li>
<li class="first"><a href="private_order.php">My Private Orders</a></li>
<li class="first"><a href="adminpass.php">My Password</a></li>
</ul>			</div>
		<hr align="center" noshade="noshade" size="2" width="100%">
        
       <h2>Customer orders</h2>
       <hr align="center" noshade="noshade" size="2" width="100%">
       <div id="adminbox">
       <?php

    if(isset($_GET['error'])){
    echo "<font style='font-size: large; color: #FF0A0A'>Please supply a valid tracking number!</font><br/><br/>";
    }
    ?>
       <b style="color:#F00">**HINTS**</b><br/> 
       <b style="color:#F00">-- "order not yet received" means you have not checked an order</b><br/>
        <b style="color:#F00"> -- "order received" indicates that you have seen and checked the order.</b><br/>
        <b style="color:#F00"> -- "product shipped" indicates that you have shipped the order.</b><br/>
       <p>&nbsp;</p>
     
      <label class="heading">Billing Details</label><br/><br/>
<table border="0" style="background:#666; font-family:Verdana, Geneva, sans-serif; font-size:11px; color:#FFF;" width="642" align="center" cellpadding="5px" cellspacing="1px">
<tr>
<td><strong>ORDER NO</strong></td>
<td><strong>NAME</strong></td>
<td><strong>ADDRESS</strong></td>
<td><strong>CONTACT</strong></td>
<td><strong>DATE ORDERED</strong></td>
<td><strong>ORDER STATUS</strong></td>
</tr>
<?php
$qd = mysqli_query($connect->connection, "SELECT * FROM orders WHERE ordernumber='$oid'");
while($row_po = mysqli_fetch_assoc($qd)){  ?>
<tr bgcolor="#FFFFFF" style="color:#000">
<td ><?php echo $row_po['ordernumber']; ?></td>
<td height="60"><?php echo $row_po['cust_fullname']; ?></td>
<td>
address: <?php echo $row_po['cust_address']; ?><br/>
city: <?php echo $row_po['cust_city']; ?><br/>
state: <?php echo $row_po['cust_state']; ?><br/>
zip: <?php echo $row_po['cust_zip']; ?><br/>
country: <?php echo $row_po['cust_country']; ?><br/>
</td>
<td><?php echo $row_po['cust_phone']; ?></td>
<td><?php echo $row_po['order_time']; ?></td>
<td style="color:#F00; font-size:14px"><b><?php echo $row_po['status']; ?></b></td>
</tr>
<?php } ?>
</table>
<br/><br/>

 

 <label class="heading">Ordered Products</label><br/><br/>
       <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:11px; background-color:#666" width="100%">
            <?php
			$o_det = mysqli_query($connect->connection, "SELECT * FROM order_details WHERE orderidno='$oid'");
            	echo '<tr style="font-weight:bold; color: #fff;"><td>S/N</td><td>Sku</td><td>Name</td><td>Unit Price</td><td>Qty</td><td>Line Total</td><td>Shipping Fees</td></tr>';
	
				$i=0;
				
				while($o_detpn = mysqli_fetch_assoc($o_det)){
			?>
            		<tr bgcolor="#fff">
                    <td><?php echo $i+1 ; $i++ ?></td>
                    <td><?php echo $o_detpn['product_sku']; ?></td>
                    <td><?php echo $o_detpn['productid']; ?></td></td>
                    <td><?php echo CONF_CURRENCY_ID."&nbsp;".$o_detpn['unitprice']; ?></td>
                    <td><?php echo $o_detpn['quantity']; ?></td>                    
                    <td><?php echo CONF_CURRENCY_ID."&nbsp;".$o_detpn['total_unit_price']; ?></td>
                     <td><?php echo CONF_CURRENCY_ID."&nbsp;".$o_detpn['shipment']; ?></td>
                    </tr>
            <?php } ?>
            </table>
            <?php $q = mysqli_query($connect->connection, "SELECT * FROM orders WHERE ordernumber='$oid'"); ?>
            <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; color: #fff; font-size:11px; background-color:#666" width="100%">
				<tr><td><b>Order Total: <?php while($ro = mysqli_fetch_assoc($q)){ echo CONF_CURRENCY_ID."&nbsp;".$ro['orderprice'];} ?></b></td><td colspan="5" align="right"></td></tr></table><br/><br/><br/>
                <?php
				$st = mysqli_query($connect->connection, "SELECT status FROM orders WHERE ordernumber='$oid'");
				$rst = mysqli_fetch_assoc($st);
				if ($rst['status'] == "order not yet received"){ ?>
                
                click "receive order" to confirm order or "not now" to confirm later.<br/><br/>
<a href="do_order.php?oid=<?php echo $oid; ?>&action=<?php echo "confirm%order"; ?>" class="button">receive order</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="myorders.php" class="button">not now</a>

<?php } if ($rst['status'] == "order received"){
	$body = "dear..........,    Your order of order number ".$oid." has been successfully shipped out. Your tracking number is..........    Thank you for shopping with us at ".$sitename;


    	?>


fill in the customer shipment message below
<form name="shipment" action="do_order.php?oid=<?php echo $oid; ?>&action=<?php echo "confirm%shippment"; ?>" method="post">
<table cellpadding="10" cellspacing="5">

       <tr>
       <td>
       <label for='sub' >Subject:</label><br/>
       </td>
       <td>
       <input type='text' value="Order Shipment Success" name='sub' id='sub' size="40" /><br/>
      
       </td>
       </tr>
       <tr>
       <td>
       <label for='body' >Body:</label><br/>
       </td>
       <td>
       <textarea type='text' name='body' id='body' rows="10" cols="40"><?php echo $body; ?></textarea><br/>
       
       </td>
       </tr>
       <tr>
       <td>
       <label for='track' >Tracking Number:</label><br/>
       </td>
       <td>
       <input type='text' name='track' id='track' size="25"/><br/>
       
       </td>
       </tr>        
       </table>

 would you like to confirm the shipment of the goods now or later?<br/><br/>
<input type="submit" class="button" value="confirm shipment" name="confirm"/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" onclick="window.location='myorders.php'" class="button" value="confirm later"/>
</form>
<?php } if ($rst['status'] == "product shipped"){?>

order has been shipped!<br/><br/>

<label class="heading">Tracking Number</label><br/><br/>
 <?php $tr = mysqli_query($connect->connection, "SELECT track_no FROM orders WHERE ordernumber='$oid'"); $rtr = mysqli_fetch_assoc($tr); ?>
 <font style="color:#F00; margin-left:40px; font-size:25px;"><?php echo $rtr['track_no']; ?></font>
<br/><br/><br/>

<a href="myorders.php" class="button"><< back</a>
<?php } ?>

<br/><br/>
    
</div>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<?php }else {$fgmembersite->RedirectToURL('myorders.php');} ?>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">

<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>