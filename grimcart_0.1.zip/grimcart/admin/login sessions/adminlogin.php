<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin login</title>
<link href="../../css/main.css" rel="stylesheet" type="text/css" />
</head>
<body class="index">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<img src="../../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" />
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">

<br><br>

<?php

session_start();
require('../../includes/connection.php');
require('../../includes/class.library.php');
$adfunc = new functions();
if(isset($_POST['Submit']))
{
$username = $adfunc->test_input($_POST['username']);
$passwd = $adfunc->test_input($_POST['password']);

$password = md5($passwd);

if ($username&&$password)
{ 
	
	$query = mysqli_query($connect->connection, "SELECT * FROM admin WHERE adminname='$username'");
	
	$numrows = mysqli_num_rows($query);
	if ($numrows!=0)
	{
		while ($row = mysqli_fetch_assoc($query))
		{
			$dbusername = $row['adminname'];
			$dbpassword = $row['adminpass'];
			}
			
			if ($username==$dbusername&&$password==$dbpassword)
			{
				echo"you are logged in! <a href='../adminhome.php'>click here</a> to enter";
				$_SESSION['admin']=$dbusername;
				$logindate=date("Y-m-d G.i:s P",time());
				$log_ip = $_SERVER['REMOTE_ADDR'];
				
				$sql = mysqli_query($connect->connection, "UPDATE `admin` SET `lastdatelog`='$logindate',`last_ip`='$log_ip' WHERE adminname='$username'");
				
				}
				else
				echo "incorrect username or password!";
			
		}
		else
		echo "invalid username and password!";

	
	}
	else 
	echo "please enter a valid username and password!";
}
else{

?>
<div class="users_login">
<fieldset>
<legend><h2>ADMIN LOGIN</h2></legend>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
<table border="0" cellspacing="5" cellpadding="5">
<tr>
<td>Username: </td>
<td><input type="text" name="username"><br></td>
</tr>
<tr>
<td>Password: </td>
<td><input type="password" name="password"><br></td>
</tr>
<tr>
<td colspan="2">
<input name="Submit" type="submit" value="Log in">
</td>
</tr>
</table>
</form>
</fieldset>
</div>
<?php } ?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">
<ul>
<li class="first"><a style="" target="_blank" href="../FAQ.php" rel="">FAQ</a></li><li class=""><a href="#">Privacy Policy</a></li>
<li class="last"><a href="#" rel="">Terms of Use</a></li>
</ul>
<p align="center"> © 2014 <?php echo $sitename; ?>. All Rights Reserved. </p>
</div>
</div>
</body>
</html>