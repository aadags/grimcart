<?PHP
require("../includes/connection.php");
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}

if(isset($_POST['submitted']))
{
   if($fgmembersite->ChangePassword())
   {
       $fgmembersite->RedirectToURL("changed-pwd.html");
   }
}
$pageurl = $_SERVER['PHP_SELF'];

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Change password</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" />
      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
      <link rel="STYLESHEET" type="text/css" href="style/pwdwidget.css" />
      <script src="scripts/pwdwidget.js" type="text/javascript"></script> 
      
        <link id="main-css" href="../css/main.css" rel="stylesheet" />
      <!-- TemplateBeginEditable name="head" -->
      <meta http-equiv="description" content="">
      <meta http-equiv="keywords" content="">
      <!-- TemplateEndEditable -->
      <script src="includes/ice/ice.js" type="text/javascript"></script>      
</head>

<body class="index">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">
<li class="first">Hi,<a id="header-signin" href="../accountmanager/index.php"><?php echo $fgmembersite->UserFullName(); ?></a></li>
<li class="first"><a id="header-signin" href="../accountmanager/index.php">My Account</a></li>
<li class="first"><a id="header-signin" href="source/logout.php?redirect_to=<?=$pageurl?>">Logout</a></li>
</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<a href="../home.php"><img src="../images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" /></a>
</div>
</div>
</div>
<div id="content-wrapper" >
  
  <div id="content" class="content">

<!-- Form Code Start -->
<div id='fg_membersite'>
<form id='changepwd' action='<?php echo $fgmembersite->GetSelfScript(); ?>' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Change Password</legend>

<input type='hidden' name='submitted' id='submitted' value='1'/>

<div class='short_explanation'>* required fields</div>

<div><span class='error'><?php echo $fgmembersite->GetErrorMessage(); ?></span></div>
<div class='container'>
    <label for='oldpwd' >Old Password*:</label><br/>
    <div class='pwdwidgetdiv' id='oldpwddiv' ></div><br/>
    <noscript>
    <input type='password' name='oldpwd' id='oldpwd' maxlength="50" />
    </noscript>    
    <span id='changepwd_oldpwd_errorloc' class='error'></span>
</div>

<div class='container'>
    <label for='newpwd' >New Password*:</label><br/>
    <div class='pwdwidgetdiv' id='newpwddiv' ></div>
    <noscript>
    <input type='password' name='newpwd' id='newpwd' maxlength="50" /><br/>
    </noscript>
    <span id='changepwd_newpwd_errorloc' class='error'></span>
</div>

<br/><br/><br/>
<div class='container'>
    <input type='submit' name='Submit' value='Submit' />
</div>

</fieldset>
</form>
<!-- client-side Form Validations:
Uses the excellent form validation script from JavaScript-coder.com-->

<script type='text/javascript'>
// <![CDATA[
    var pwdwidget = new PasswordWidget('oldpwddiv','oldpwd');
    pwdwidget.enableGenerate = false;
    pwdwidget.enableShowStrength=false;
    pwdwidget.enableShowStrengthStr =false;
    pwdwidget.MakePWDWidget();
    
    var pwdwidget = new PasswordWidget('newpwddiv','newpwd');
    pwdwidget.MakePWDWidget();
    
    
    var frmvalidator  = new Validator("changepwd");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("oldpwd","req","Please provide your old password");
    
    frmvalidator.addValidation("newpwd","req","Please provide your new password");

// ]]>
</script>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->
</div>
</div>
<!-- footer -->
<div id="footer-wrapper">
<div id="footer" class="content">
<ul>
<li class="first"><a style="" target="_blank" href="../FAQ.php" rel="">FAQ</a></li><li class=""><a href="#">Privacy Policy</a></li>
<li class="last"><a href="#" rel="">Terms of Use</a></li>
</ul>
<ul><p align="center"> © 2014 <a href="../home.php"><?php echo $sitename; ?></a>. All Rights Reserved. </p> </ul>
</div>
</div>

</body>
</html>
