<?php
/*
  -------------------------------------------------------------------------
      DR webtech's  GRIMCART
              Version 0.1
    This program is free software published under the
    terms of the GNU Lesser General Public License.

    This program is distributed in the hope that it will
    be useful - WITHOUT ANY WARRANTY; without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A
    PARTICULAR PURPOSE.


	Questions & comments please send to damahrefeay@gmail.com
  -------------------------------------------------------------------------
*/
require('../includes/connection.php');
require('../includes/class.library.php');
require_once("../source/include/membersite_config.php");

$admin_upload = new form();
$adfunc = new functions();

$target = "../images/thumbnail/"; 

$target = $target . basename( $_FILES['thumbnail']['name']);		

$name = $admin_upload->test_input($_POST['productname']);
$desc = $admin_upload->test_input($_POST['prod_desc']);
$spec = $admin_upload->test_input($_POST['prod_spec']);
$price = $admin_upload->test_input($_POST['price']);
$shipprice = $admin_upload->test_input($_POST['shipprice']);
$listprice = $admin_upload->test_input($_POST['listprice']);
$sku = $admin_upload->test_input($_POST['prod_sku']);
$instock = $admin_upload->test_input($_POST['stock']);
$catID = $admin_upload->test_input($_POST['categoryid']);

	 $thumbnail = $_FILES['thumbnail']['name']; 
	 
	 


if ( $thumbnail == false )
{
	echo "<p style='color:#F00'><strong>please insert a thumbnail!</strong></p>";
}
if ( $shipprice == false )
{
	echo "<p style='color:#F00'><strong>please insert a shipping price!</strong></p>";
}
	  	
else if ( $name == false )
{
	echo "<p style='color:#F00'><strong>Name cannot be left blank!</strong></p>";
}
else if ( $desc == false )
{
	echo "<p style='color:#F00'><strong>Description cannot be left blank!</strong></p>";
}
else if ( $price == false )
{
	echo "<p style='color:#F00'><strong>Price cannot be left blank!</strong></p>";
}

else if (!(is_numeric($instock)))
{
	echo "<p style='color:#F00'><strong>Invalid stock!</strong></p>";
}
else if ( $sku == false )
{
	echo "<p style='color:#F00'><strong>Product Sku cannot be left blank!</strong></p>";
}
else if ( $adfunc->checkproductname($name) )
{
	echo "<p style='color:#F00'><strong>Name already exists' try again!</strong></p>";
}
else if ( $adfunc->checkproductsku($sku) )
{
	echo "<p style='color:#F00'><strong>Product Sku already exists' try again!</strong></p>";
}

else{
	$allowedExts = array("gif","jpeg","jpg","png");
	$temp = explode(".", $_FILES['thumbnail']['name']);
	$extension = end($temp);
	
	if ((($_FILES['thumbnail']['type'] == "image/gif") || ($_FILES['thumbnail']['type'] == "image/jpeg") || ($_FILES['thumbnail']['type'] == "image/jpg") || ($_FILES['thumbnail']['type'] == "image/pjpeg") || ($_FILES['thumbnail']['type'] == "image/x-png") || ($_FILES['thumbnail']['type'] == "image/png") && in_array($extension, $allowedExts)))
    {

    if ($_FILES['thumbnail']['error']> 0) {
	echo "error : ".$_FILES['thumbnail']['error']."<br>";
	 }
	  else
       {
	
	if(move_uploaded_file(($_FILES['thumbnail']['tmp_name']), $target))
      {

	$sql = mysqli_query($connect->connection, "INSERT INTO `products`"."(`categoryID`, `prod_name`, `prod_specs`, `in_stock`, `price`, `listprice`, `prod_desc`, `prod_sku`, `thumbnail`, `shipment`)". "VALUES ('$catID','$name','$spec','$instock','$price','$listprice','$desc','$sku','$thumbnail','$shipprice')");


	if ($sql)
	{
		$fgmembersite->RedirectToURL("picupload.php?sku=".$sku);
	}
	else
	{
		echo'data not saved successfully to database ';
	
	}
	 }
        else { 
             //Gives and error if its not 
             echo "Sorry, there was a problem uploading thumbnail ". basename( $_FILES['thumbnail']['name'])."due to error : ".$_FILES['thumbnail']['error']; 
             }	
																																																																															 }
																																																																																																																																																																																																																																												 }
																																																																																																																																																																																																																																												 else {	echo "invalid file";}																																																																													 																																																																															 }


  ?>