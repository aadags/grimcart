<?php
    define('CONF_SHOP_NAME', 'DR webtech');
    define('CONF_GENERAL_EMAIL', 'admin@drdesigns.com');
	define('CONF_NOTIFICATION_EMAIL', 'rootuser3@localhost.com');
	define('CONF_CURRENCY_ID', '$');
	define('CONF_CURRENCY_ISO3', 'US');
	define('CONF_PAYPAL_EMAIL', 'aadags@yahoo.com');
	define('CONF_PRODUCTS_PER_PAGE', 1);
     ?>