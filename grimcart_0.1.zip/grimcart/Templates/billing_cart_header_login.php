<!DOCTYPE html>
<html>
<head>
<!-- TemplateBeginEditable name="doctitle" -->
<title><?php echo $title; ?></title>
<!-- TemplateEndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link id="main-css" href="./css/main.css" rel="stylesheet" />
<!-- TemplateBeginEditable name="head" -->
<meta http-equiv="description" content="">
<meta http-equiv="keywords" content="">
<!-- TemplateEndEditable -->
</head>
<body class="products_results">	
<div id="user-menu-wrapper">
<div id="user-menu" class="content">
<ul id="header-menu">
<?PHP

if ($fgmembersite->CheckLogin())

{
?>
   <li class="first">Hi,<a id="header-signin" href="accountmanager/index.php"><?php echo $fgmembersite->UserFullName(); ?></a></li>
   <li class="first"><a id="header-signin" href="accountmanager/index.php">My Account</a></li>

 <?php }?>

</ul></div>
</div>
<div id="header-wrapper">
<div id="header" class="content">
<div class="logo">
<a href="home.php"><img src="images/nyrahlogoreal.png" alt="My Store" width="227" height="110" id="header-logo" /></a>
</div>
</div>
</div>
<!-- main menu -->
<div id="top-wrapper">
<div id="top" class="content">
<div id="top-search">

</div>
<ul id="top-menu">

</ul>
</div>
</div>
<div id="content-wrapper">
<div id="content" class="content">