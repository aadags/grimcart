<?php

require("../includes/class.library.php");
$func = new functions();

$func->RedirectToURL("adminhome.php");

?>